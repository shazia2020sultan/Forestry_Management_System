package com.abridged.forestrymanagementsystem.exception;

public class EmptyRecordException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
