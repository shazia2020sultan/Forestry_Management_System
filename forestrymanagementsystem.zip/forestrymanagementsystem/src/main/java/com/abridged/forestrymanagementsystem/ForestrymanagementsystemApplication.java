package com.abridged.forestrymanagementsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * The ForestrymanagementsystemApplication program implements an application that executes forestry
 * management system.
 * 
 * @author Suyash
 * 
 */
@SpringBootApplication
public class ForestrymanagementsystemApplication {

	/**
	 * This is the main method.
	 * 
	 * @param args Unused.
	 * @return Nothing.
	 * @exception NotFoundExceptionException               on input error.
	 * @exception EmptyRecordException                     on input error.
	 * @exception AlreadyPresentException                  on input error.
	 * @see NotFoundException.
	 * @see EmptyRecordException.
	 * @see AlreadyPresentException.
	 * 
	 */
	public static void main(String[] args) {
		SpringApplication.run(ForestrymanagementsystemApplication.class, args);
	}

}
