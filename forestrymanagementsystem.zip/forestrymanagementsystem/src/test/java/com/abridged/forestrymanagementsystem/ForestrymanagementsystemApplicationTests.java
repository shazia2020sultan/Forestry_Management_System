package com.abridged.forestrymanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForestrymanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
